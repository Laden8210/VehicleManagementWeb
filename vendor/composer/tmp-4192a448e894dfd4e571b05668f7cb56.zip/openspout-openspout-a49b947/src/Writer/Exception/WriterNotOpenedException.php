<?php

declare(strict_types=1);

namespace OpenSpout\Writer\Exception;

final class WriterNotOpenedException extends WriterException {}
